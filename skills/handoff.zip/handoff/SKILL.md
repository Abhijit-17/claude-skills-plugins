---
name: handoff
description: Compact the current conversation into a handoff document for another agent to pick up. Use only when the user asks for a handoff by name. The user may say what the next session will focus on.
license: MIT
metadata:
  upstream: mattpocock/skills@49dd158 skills/productivity/handoff
  build: "2026-10-15.1"
---

Read [RUNTIME.md](RUNTIME.md) first.

Write a handoff document summarising the current conversation so a fresh agent can continue the work.

**Check for a local handoff format first.** Some workspaces keep their own handoff files (for example `*-HANDOFF.md` next to `MISSION.md`), or another skill in use owns its own handoff step. If so, ask the user which one they want: that format and place, or this temporary document. Do not write both.

Otherwise, name it `handoff-<short-topic>-<timestamp>.md`, and never save it in the repo or project workspace.

- **Local machine:** save it to the temporary directory of the user's OS (`$TMPDIR`, else `/tmp`; `%TEMP%` on Windows) and tell the user the absolute path.
- **Cloud sandbox:** save it in your working folder and send the file to the user with the file-sending tool. The user cannot see a temp folder in the sandbox. In a Project chat, end your reply with one line that offers to save the handoff to the Project (RUNTIME.md section 5). Save it only after a yes.

Include these sections:

- **Read order**: which files, docs or links the next agent reads first, in order.
- **Do not redo**: work that is done and verified, so the next agent does not repeat it.
- **Verify**: commands or checks that prove the current state (for example a test command, `git status`, a file that must exist).
- **Suggested skills**: which skills the next agent should load.

Do not duplicate content already captured in other artifacts (specs, plans, ADRs, issues, commits, diffs). Reference them by path or URL instead. For files that exist only in this sandbox, say so; the next agent cannot reach them unless the user saves them.

Redact any sensitive information, such as API keys, passwords, or personally identifiable information.

If the user said what the next session will focus on, tailor the doc to that.
