---
name: grilling
description: Grill the user relentlessly about a plan, decision, or idea. Use when the user wants to stress-test their thinking, or uses any 'grill' trigger phrases.
license: MIT
metadata:
  upstream: mattpocock/skills@49dd158 skills/productivity/grilling
  build: "2026-10-15.1"
---

Read [RUNTIME.md](RUNTIME.md) first.

Interview the user relentlessly until you reach a shared understanding. Map this as a **design tree**: every decision branches into the decisions that hang off it.

Work the tree in **rounds**. The **frontier** is every decision whose prerequisites are already settled: the questions you can ask _now_ without guessing at answers you haven't heard yet. Ask the whole frontier in one round: number each question and give your recommended answer. Then wait for the user's answers before the next round.

Format a round like so:

```
❓ **Q1** - **<question title>**: <question body, might be multiple paragraphs, including multiple choices>

➡️ <your recommended answer>

---

❓ **Q2** - **<question title>**: <question body, might be multiple paragraphs, including multiple choices>

➡️ <your recommended answer>
```

Word each question so "yes" accepts your recommended answer.

Each round the user answers reshapes the tree: settled decisions push the frontier outward and unblock questions that depended on them. Recompute the frontier and ask the next round. A question whose answer depends on another question still open in this round belongs to a _later_ round, not this one.

Finding _facts_ is your job, never the user's. When a frontier question needs a fact from the environment (filesystem, tools, uploaded files, project knowledge, etc.), find it; don't ask the user for anything you could look up yourself. How you find it depends on the agent mode in RUNTIME.md:

- **Parallel:** dispatch a sub-agent to find it. Don't block on it: a running exploration is an unsettled prerequisite, so only the questions downstream of it wait for the sub-agent to report; ask the rest of the frontier now.
- **One at a time:** same as Parallel, but keep at most one lookup sub-agent running. Start the next lookup only after the last one reports.
- **No sub-agents:** look it up yourself before you send the round. If the lookup is long, send the questions that don't depend on it first, and move the dependent questions to the next round.

Do small lookups yourself, with no agent-mode question (for example, reading a file that the user named). Ask the agent-mode question only when the first lookup that needs a sub-agent comes up (for example, a search across many files), not at the start. The _decisions_ are the user's: put each to them and wait.

The session is done when the frontier is empty: every branch of the design tree visited, nothing left silently assumed. Do not act on it until the user confirms you have reached a shared understanding.
