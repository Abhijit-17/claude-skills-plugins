---
name: grill-with-docs
description: A relentless interview to sharpen a plan or design, which also writes docs (GLOSSARY.md and ADRs) as decisions land. Use only when the user asks for grill-with-docs by name, or asks to grill a plan or design with docs.
license: MIT
metadata:
  upstream: mattpocock/skills@7739eae skills/engineering/grill-with-docs
  build: "2026-10-30.1"
  requires: grilling, domain-modeling
---

Read [RUNTIME.md](RUNTIME.md) first. Skip it only if you already read a RUNTIME.md with the line `Build: 2026-10-30.1` in this session.

Load two skills, one call each: "grilling", then "domain-modeling". Run both disciplines together for the whole session. The grilling walks the design tree; the domain modeling writes `GLOSSARY.md` and ADRs as decisions land.
