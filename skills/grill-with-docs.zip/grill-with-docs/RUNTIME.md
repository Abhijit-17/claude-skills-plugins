# Runtime rules

Build: 2026-10-15.1 (adapted from mattpocock/skills@49dd158)

These rules adapt this skill to these surfaces: Claude Code CLI, the Claude desktop app (Code tab, chat and Projects), and claude.ai chat and Projects. Read them before step 1 of the skill. When this file and SKILL.md disagree about agents, files, or loading skills, this file wins.

## 1. Know where you run

There are two cases.

- **Local machine.** You run on the user's own computer (Claude Code CLI, or the desktop Code tab on a local folder). The user can see the files you write. You can open a file for them with `open` (macOS), `xdg-open` (Linux) or `start` (Windows). Signs: paths start with `/Users/` (macOS), `/home/<user>/` on the user's Linux computer, or `C:\` (Windows).
- **Cloud sandbox.** You run in a remote container (claude.ai chat, desktop chat, a Project chat, or a cloud Code session). The user cannot see your filesystem or your temp folder. Signs: a file-sending tool exists (for example `SendUserFile` or `present_files`), or paths start with `/mnt/` or `/home/claude`.

If you cannot tell, ask the user once.

## 2. Agent mode: ask before the first sub-agent

Sub-agents use the user's usage limit. The user decides once per session.

Before the first step that can use a sub-agent, ask the user this question. Use a multiple-choice question tool if you have one:

> How do I run the steps that can use sub-agents?
>
> 1. **Parallel**: I start the sub-agents at the same time. This is the fastest. It uses the most of your limit at one time. If a limit stops the work, all running sub-agents stop.
> 2. **One at a time**: I start one sub-agent, wait for its report, then start the next. This is slower. Each step keeps its own context. If a limit stops the work, less work is lost.
> 3. **No sub-agents**: I do each step myself in this conversation. No extra agent starts. This conversation gets longer, and the steps share one context.

Rules:

- Ask only once per session. Use the answer for every skill in this session, including skills this skill loads.
- If the user already named a mode in the request (for example, "one sub-agent at a time"), use it. Do not ask.
- If you have no sub-agent tool, do not ask. Use **No sub-agents** and tell the user in one line.
- If no one can answer, do not stop to ask. Examples: a scheduled run, or a print or headless run (for example `claude -p`) where you have no question tool. Use **No sub-agents**, and say so in the first line of your output. Tell the user that they can name a mode in the request next time.
- **Parallel:** start the sub-agents together, as the skill says.
- **One at a time:** start one sub-agent. Wait for its report. Then start the next one. Give each sub-agent the same brief that it gets in Parallel mode. Do not give it the reports of the earlier sub-agents, unless the skill says so.
- **No sub-agents:** do the work of each sub-agent yourself, one step after another. Where the skill keeps two reviews or designs separate, finish one fully before you start the next. Do not let the first one change the second.
- If a sub-agent stops early (usage limit, session limit, or error), do not trust its own "done" message. Check its real output (files, report text) before you use it. Tell the user what is missing.

## 3. Load other skills

When this skill says "load the X skill":

1. If you have a Skill tool, find X in your skill list. Call the tool with the name **exactly as the list shows it**. The name can have a prefix. Skills uploaded to claude.ai often show as `anthropic-skills:X`. A bare "X" call fails when the list shows a prefix.
2. If you have no Skill tool, or the call fails, read `X/SKILL.md` from a skills folder: `/mnt/skills/user/`, `/mnt/skills/plugins/`, `~/.claude/skills/`, or `~/.claude/skills/synced/`.
3. If you cannot find it, tell the user: "Install the X skill (X.zip) to use this step." Then continue with what you can do.

## 4. Get the code

If the skill needs a git repo and your working folder has none, do not guess. Ask the user for one of these:

- a GitHub repo to attach or clone,
- a local folder to connect (desktop app),
- a ZIP of the repo. Ask them to include the `.git` folder if the skill reads history.

Cloud clones are often shallow, or have one branch only. Before you read history (`git log`) or diff against a base (`git diff <base>...HEAD`), do these steps:

1. Run `git rev-parse --is-shallow-repository`. If the result is `true`, run `git fetch --unshallow`.
2. Run `git rev-parse --verify <base>`. If the base is missing, run `git fetch origin <base>:refs/remotes/origin/<base>`. Then use `origin/<base>` as the base.
3. If you cannot fetch, tell the user that the history is incomplete. Do not report a partial diff as a full diff.

## 5. Write and deliver files

- **Local machine:** follow the skill as written.
- **Cloud sandbox:** write the file in your working folder, not in a temp folder. Then send it to the user with the file-sending tool. Give the user the result, not the path. Do not show sandbox paths (for example `/home/claude/...` or `/mnt/...`) in your reply. The user cannot open them.
- **Project chat:** you are in a Project chat when the session names an attached Project, or when you have a tool that writes Project docs (for example a `Projects` tool with `project_write`). In a Project chat, after you send a file that the user keeps (a report, `GLOSSARY.md`, an ADR, or a handoff), always end your reply with one line that offers to save it to the Project. Example: "Do you want me to save GLOSSARY.md to the Project?" Save it only after a yes. Offer once for each file in each round. If you are in a Project but have no tool that writes Project docs, tell the user once that they can add the file to the Project by hand.
- **Do not publish without a yes.** A report about a codebase can contain confidential code or design. Do not publish it as an artifact or web page unless the user says yes. You can offer it once.

## 6. Store docs (GLOSSARY.md, ADRs)

- **Writable repo or folder that the user keeps:** write the files there, as the skill says.
- **No such place (plain chat or Project chat):** keep each doc as a file in your working folder. Send the updated files to the user once at the end of each round of questions, not after each term. Tell the user once, early, that the docs live in this conversation until they save them. In a Project chat, follow the Project offer rule in section 5.
