# Tracker and domain docs

This file tells you where specs and tickets live, and where the domain docs are. It replaces any setup step. You do not need a setup skill.

## 1. Look for the repo's own configuration first

The repo can have its own tracker docs. If it does, follow them. They override section 2 of this file.

1. Look for a `## Agent skills` section in `CLAUDE.md` or `AGENTS.md` at the repo root. It can name the tracker doc, the label doc and the domain doc.
2. If it names none, look for these default paths:
   - `docs/agents/issue-tracker.md`: the tracker doc. Follow it for every tracker action (publish, fetch, comment, label, blocking links).
   - `docs/agents/triage-labels.md`: the label doc. See section 3.
   - `docs/agents/domain.md`: the domain doc. See section 4.
3. If you find a tracker doc, use it and ignore section 2. If you find none, use the local markdown tracker in section 2.

Do not ask the user to run a setup skill.

## 2. Local markdown tracker (default)

Specs and tickets for this repo live as markdown files in `.scratch/`.

- One feature per directory: `.scratch/<feature-slug>/`. Choose a short kebab-case slug from the feature name. If `.scratch/` already has a directory for this feature, or the user gave a slug, use that one.
- The spec is `.scratch/<feature-slug>/spec.md`.
- Tickets are one file per ticket at `.scratch/<feature-slug>/issues/<NN>-<slug>.md`, numbered from `01`. Never use a single combined tickets file.
- Triage state is a `Status:` line near the top of the file. This applies to `spec.md` and to each ticket file.
- Status values: `ready-for-agent` (see section 3) and `done`. `done` means that the work of the ticket is finished. `done` is not a triage role.
- Commit the `.scratch/` folder to git. The spec and the tickets are part of the history, beside the code. Do not put `.scratch/` in `.gitignore`.
- Comments and conversation history append to the bottom of the file under a `## Comments` heading.

When a skill says "publish to the issue tracker": create a new file under `.scratch/<feature-slug>/`. Create the directory if it does not exist.

When a skill says "fetch the relevant ticket": read the file at the referenced path. The user will normally pass the path or the issue number directly. If a number matches more than one file, ask the user which one they mean.

**Where the files go:**

- **Local machine:** write the files in the repo.
- **Cloud sandbox:** the user cannot see your files. Write them in the repo clone if you have one, or else in your working folder. Then send every file you wrote with the file-sending tool. If you have no file-sending tool, print the file text in your reply, in a code block. If the file is too long for that, say plainly that you cannot send files in this session, and say where the file is. Follow RUNTIME.md section 5 for Project chats.

## 3. Triage label

The skills that use this file need one triage role: `ready-for-agent`. It means "fully specified, ready for an AFK agent".

- Local tracker: write `Status: ready-for-agent` near the top of the file.
- If the label doc exists, find the row for `ready-for-agent`. Use the string in its "Label in our tracker" column.
- Do not change any other triage role.

## 4. Domain docs

Before you explore the codebase, read these files. If the domain doc exists, follow it as well.

- `GLOSSARY.md` at the repo root. Older repos may call it `CONTEXT.md`.
- Or `GLOSSARY-MAP.md` at the repo root (older name: `CONTEXT-MAP.md`) if it exists. It points to one `GLOSSARY.md` per context. Read each one that is relevant to the topic.
- `docs/adr/`. Read the ADRs that touch the area you will work in. In a multi-context repo, also read `src/<context>/docs/adr/`.

If a file does not exist, go on without a comment. Do not say that it is missing. Do not suggest that the user creates it. The "domain-modeling" skill creates these files when terms or decisions are resolved.

When your output names a domain concept (in a spec, a ticket title or a test name), use the term as `GLOSSARY.md` defines it. Do not use a synonym that the glossary says to avoid. If the glossary has no term for the concept, that is a signal. Either you invent language that the project does not use (reconsider), or the glossary has a real gap (note it for the "domain-modeling" skill).

If your output contradicts an ADR, say so. Do not override it silently. For example:

> _Contradicts ADR-0007 (event-sourced orders), but worth reopening because…_

## 5. Optional path: a real tracker (GitHub, GitLab, Linear, and others)

Use a real tracker only in one of these two cases:

- A tracker doc exists (section 1). Follow it.
- The user names a tracker and tells you how to use it, in a short paragraph. Follow that paragraph.

In any other case, use the local tracker in section 2. Do not guess `gh`, `glab` or other commands, and do not create labels on a tracker that no doc describes.

A tracker doc can be too thin. This is the case when it does not say how to publish, which label or status string to use, and which repo or project. In that case, do these steps:

1. Write the item as a draft file under `.scratch/<feature-slug>/`, as section 2 describes.
2. Ask the user for the missing facts.
3. Run no tracker command.
