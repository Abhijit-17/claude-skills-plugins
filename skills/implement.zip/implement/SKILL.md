---
name: implement
description: "Implement a piece of work based on a spec or set of tickets. Use only when the user asks for implement by name."
license: MIT
metadata:
  upstream: mattpocock/skills@7739eae skills/engineering/implement
  build: "2026-11-13.2"
  requires: tdd, two-axis-review
---

Read [RUNTIME.md](RUNTIME.md) first. Skip it only if you already read a RUNTIME.md with the line `Build: 2026-11-13.2` in this session. If your working folder has no code, get it (RUNTIME.md section 4) before you start.

Implement the work described by the user in the spec or tickets.

If the user passes a ticket reference, fetch it from the issue tracker (see [TRACKER.md](TRACKER.md)) and state its title before starting. If the reference is ambiguous, ask.

Load the "tdd" skill where possible, at pre-agreed seams.

Run typechecking regularly, single test files regularly, and the full test suite once at the end. If the project has no type check, skip that part and say so.

When the work of a ticket is done, and before you commit, update the ticket in the tracker. With the local tracker, tick each acceptance criterion that is met. Then change the `Status:` line of the ticket to `done`. Include the ticket file in the same commit. If the user commits, list the ticket file in the `git add` command. With a real tracker, follow the repo's tracker doc.

Once done, commit your work to the current branch. Do not commit if git cannot write here (for example, a sandbox that cannot remove lock files), or if the user's rules say the user commits. Give the user the exact commands to run instead: `git add` with the real file names, then `git commit` with a message.

Then load the "two-axis-review" skill to review the work. The review reads committed changes only. If the user commits, wait until the user confirms the commit. If the review leads to changes, commit them in the same way.
