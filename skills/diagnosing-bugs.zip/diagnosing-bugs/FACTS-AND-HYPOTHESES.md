# Facts and hypotheses: the two-tier method

A local addition of this build (not upstream). The method is from Cindy Sridharan, "How to effectively debug when you no longer understand the code" (2026-10), in our own words. Use it for a production bug, a bug in code that you do not know well, or a bug where your first hypotheses keep failing. For a simple local bug with a clear loop, the main phases are enough.

## The two tiers

- **Facts (the bottom tier).** Data that comes from outside you: error logs, crash reports, stack traces, profiles, telemetry, traces, packet captures, process state, configuration, feature flags, versions, deploys, version history, user reports. Give each fact an ID (F1, F2, ...) and its source. You can read, analyse and ask for facts. You cannot change or dispute a fact. If you doubt how a fact was collected, tell the user and ask them to collect it again.
- **Hypotheses (the top tier).** Everything that you infer: causes, theories, suspicions, and also each repro that you make. Give each hypothesis an ID (H1, H2, ...).

Each fact is a constraint. A hypothesis is valid only if it agrees with every fact. One fact that contradicts it removes it.

Keep the fact list large and the hypothesis list small. Collect the same kind of data from several instances of the bug (two hosts, two users) when you can: a pattern that repeats in the bug cases and not in the control is a real signal. Prefer counts and measurements (bytes, lookups, requests, time to first byte) over impressions.

## Phase 0: facts and a control (before Phase 3)

1. Write the fact list (F1, F2, ...) with the source of each fact. Start with what you already have (the bug report, logs, telemetry, configuration). Collect more only when step 2 of Phase 3 needs it.
2. Choose a **control**: a case to compare with the bug case (the **variable**). The best control is the same as the variable except for the suspected change, for example the same code with the feature flag off. If the working case differs in too many ways, use a case that also fails, but in a different and louder way, with a cause that you understand.
3. Sort the facts:
   - A **signal** shows in the variable and not in the control. Signals tell you where to look.
   - **Noise** shows in both. Noise never tells you where to look, but it removes each hypothesis that depends on it.
4. Check that the control is not broken in the same way as the variable. A broken control turns each signal into noise.

## Phase 2 addition: signal parity of the repro

A repro is a hypothesis, not a fact. It proves that *a* bug exists, not that it is *this* bug. Before you trust a repro, check that it shows the strongest signal from the fact list (the same error, the same stack frame, the same packet pattern). If it does not, it is a different bug: do not use it.

## Phase 3 addition: the hypotheses-by-facts table

Make a table: one row for each hypothesis, one column for each fact (signals first). Write ✓ where the hypothesis agrees with the fact and ✗ where the fact contradicts it. Show the table to the user.

1. **Read the columns.** A **strong** signal agrees with very few hypotheses, ideally one. A weak signal agrees with almost all of them (service-level latency or error-rate numbers are often weak: they are symptoms). Follow the strongest signal: test first the hypothesis that it points to.
2. **Read the rows.** Only a row with no ✗ is a candidate.
3. **If no row is free of ✗**, use these tactics in this order before you invent a new hypothesis:
   1. Check how each contradicting fact was collected (the wrong host, the wrong time window, the wrong tool version). Ask the user to collect it again if it is suspect.
   2. **Split** a hypothesis that is too broad ("the deploy caused it" becomes one hypothesis for each change in the deploy).
   3. **Merge** hypotheses that are too narrow (many host-level causes become "something that all these hosts share").
   4. **Combine** two hypotheses that each explain part of the facts and contradict none. Each cause in a combination must be necessary: remove one, and a fact must stay unexplained.
   5. Only then, make a new hypothesis, from the facts only.
4. **If all signals are weak, or each row still has a ✗**, do not make more hypotheses. Collect facts from one layer lower (for example: logs, then packet captures, then process state, then kernel or runtime tables). Stop at the first layer that gives a strong signal. Go back to step 1.

## Phase 5 addition: validate against every fact

Before the fix, check the chosen hypothesis against every fact, also the noise. Each claim in your explanation cites a fact ID. A claim without a fact is removed. For a combined hypothesis, remove each cause in turn and show which fact it leaves unexplained.

## Review sub-agent (optional)

If the user chose an agent mode with sub-agents (RUNTIME.md section 2), a reviewer can help, but only to **remove** things, never to confirm them. Give it the fact list, the control and the table. Ask it to: find signals that also show in the control; check that the control is not broken the same way; find one fact that contradicts the chosen hypothesis; and, for a combination, test that each cause is necessary. A reviewer cannot see facts that nobody collected, so its agreement proves nothing.
